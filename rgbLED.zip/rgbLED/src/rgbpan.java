
import com.panamahitek.ArduinoException;
import com.panamahitek.PanamaHitek_Arduino;
import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import jssc.SerialPortException;

/**
 *
 * @author Mario J. Mora López
 */
public class rgbpan extends javax.swing.JFrame {
    int R=0,G=0,B=0;
    PanamaHitek_Arduino arduino=new PanamaHitek_Arduino();
    String OutputR,OutputG,OutputB;
    public rgbpan() {
        initComponents();
        ini();
    }
    
public void ini(){    
    try {
            arduino.arduinoTX("COM12", 9600);
        } catch (ArduinoException ex) {
            Logger.getLogger(rgbpan.class.getName()).log(Level.SEVERE, null, ex);
        }
}
public void SetData() {
OutputR = "r";
if (R < 10) {
OutputR = OutputR + "00" + R;
} else if (R < 100) {
OutputR = OutputR + "0" + R;
} else {
OutputR = OutputR + R;
}
OutputG = "g";
if (G < 10) {
OutputG = OutputG + "00" + G;
} else if (R < 100) {
OutputG = OutputG + "0" + G;
} else {
OutputG = OutputG + G;
}

OutputB = "b";
if (B < 10) {
OutputB = OutputB + "00" + B;
} else if (R < 100) {
OutputB = OutputB + "0" + B;
} else {
OutputB = OutputB + B;
}
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField3 = new javax.swing.JTextField();
        srojo = new javax.swing.JSlider();
        sverde = new javax.swing.JSlider();
        sazul = new javax.swing.JSlider();
        pcolor = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tr = new javax.swing.JTextField();
        tg = new javax.swing.JTextField();
        tb = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        srojo.setBackground(new java.awt.Color(255, 0, 0));
        srojo.setMaximum(255);
        srojo.setPaintTicks(true);
        srojo.setValue(0);
        srojo.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                srojoStateChanged(evt);
            }
        });

        sverde.setBackground(new java.awt.Color(0, 204, 0));
        sverde.setMaximum(255);
        sverde.setPaintTicks(true);
        sverde.setValue(0);
        sverde.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sverdeStateChanged(evt);
            }
        });

        sazul.setBackground(new java.awt.Color(0, 0, 255));
        sazul.setMaximum(255);
        sazul.setPaintTicks(true);
        sazul.setValue(0);
        sazul.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sazulStateChanged(evt);
            }
        });

        pcolor.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout pcolorLayout = new javax.swing.GroupLayout(pcolor);
        pcolor.setLayout(pcolorLayout);
        pcolorLayout.setHorizontalGroup(
            pcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 156, Short.MAX_VALUE)
        );
        pcolorLayout.setVerticalGroup(
            pcolorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 156, Short.MAX_VALUE)
        );

        jLabel1.setText("Rojo");

        jLabel2.setText(" Verde");

        jLabel3.setText("Azul");

        tr.setEditable(false);

        tg.setEditable(false);

        tb.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(115, 115, 115)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(124, 124, 124)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(sverde, javax.swing.GroupLayout.DEFAULT_SIZE, 255, Short.MAX_VALUE)
                                    .addComponent(srojo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sazul, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tr)
                                    .addComponent(tg, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                                    .addComponent(tb, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE))))
                        .addGap(18, 18, 18)
                        .addComponent(pcolor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pcolor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(srojo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sverde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sazul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void srojoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_srojoStateChanged
        R=srojo.getValue();
        String rr=Integer.toString(R);
        tr.setText(rr);
        SetData();
        try {
            arduino.sendData(OutputR);
        } catch (ArduinoException ex) {
            Logger.getLogger(rgbpan.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SerialPortException ex) {
            Logger.getLogger(rgbpan.class.getName()).log(Level.SEVERE, null, ex);
        }
        pcolor.setBackground(new Color(R,G,B));
    }//GEN-LAST:event_srojoStateChanged

    private void sverdeStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sverdeStateChanged
        G=sverde.getValue();
        String gg=Integer.toString(G);
        tg.setText(gg);
        SetData();
        try {
            arduino.sendData(OutputG);
        } catch (ArduinoException ex) {
            Logger.getLogger(rgbpan.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SerialPortException ex) {
            Logger.getLogger(rgbpan.class.getName()).log(Level.SEVERE, null, ex);
        }
        pcolor.setBackground(new Color(R,G,B));
    }//GEN-LAST:event_sverdeStateChanged

    private void sazulStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sazulStateChanged
        B=sazul.getValue();
        String bb=Integer.toString(B);
        tb.setText(bb);
        SetData();
        try {
            arduino.sendData(OutputB);
        } catch (ArduinoException ex) {
            Logger.getLogger(rgbpan.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SerialPortException ex) {
            Logger.getLogger(rgbpan.class.getName()).log(Level.SEVERE, null, ex);
        }
        pcolor.setBackground(new Color(R,G,B));
    }//GEN-LAST:event_sazulStateChanged

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(rgbpan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(rgbpan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(rgbpan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(rgbpan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new rgbpan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JPanel pcolor;
    private javax.swing.JSlider sazul;
    private javax.swing.JSlider srojo;
    private javax.swing.JSlider sverde;
    private javax.swing.JTextField tb;
    private javax.swing.JTextField tg;
    private javax.swing.JTextField tr;
    // End of variables declaration//GEN-END:variables
}
